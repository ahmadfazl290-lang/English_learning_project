'use client';
import React,{useEffect,useState,useRef} from 'react';
import SupabaseAccount from './SupabaseAccount';
export default function AccountLinks(){
 const [legacy,setLegacy]=useState(null);
 useEffect(()=>{const params=new URLSearchParams(location.search);setLegacy(params.get('provider')!=='supabase'&&(location.hash.includes('action=')||['verify','reset'].includes(params.get('mode'))));},[]);
 if(legacy===null)return <main aria-busy="true" className="min-h-screen flex items-center justify-center">English-Co…</main>;
 return legacy?<LegacyAccountLinks/>:<SupabaseAccount/>;
}
function LegacyAccountLinks(){
 const [loading,setLoading]=useState(true),[action,setAction]=useState(''),[token,setToken]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[confirm,setConfirm]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[success,setSuccess]=useState(false),[message,setMessage]=useState('');
 const parsed=useRef(false);
 useEffect(()=>{if(parsed.current)return;parsed.current=true;const fragment=new URLSearchParams(location.hash.slice(1));const selected=fragment.get('action');if(['verify','reset'].includes(selected)){setAction(selected);setToken(fragment.get('token')||'');history.replaceState(null,'','/account');}else{setAction(new URLSearchParams(location.search).get('mode')==='verify'?'request_verification':'request_reset');}setLoading(false);},[]);
 const requestMode=action.startsWith('request_');
 async function submit(event){event.preventDefault();if(busy)return;setError('');setMessage('');
  if(!requestMode&&password!==confirm){setError('وشە نهێنییەکان وەک یەک نین.');return;}
  setBusy(true);
  try{const r=await fetch('/api/account-email',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,token,password,email})});const data=await r.json();if(!r.ok)throw new Error(data.error);
   if(requestMode)setMessage('ئەگەر ئەم هەژمارە گونجاو بێت، ڕێنمایی بۆ ئیمەیڵەکەت دەنێردرێت. ناوەڕۆکی Inbox و Spam بپشکنە.');else{setToken('');setPassword('');setConfirm('');setSuccess(true);}
  }catch(e){const errors={'This link is invalid or expired.':'ئەم لینکە بەسەرچووە یان دروست نییە. لینکی نوێ داوا بکە.','Email delivery is not configured yet.':'ناردنی ئیمەیڵ هێشتا چالاک نەکراوە.','Too many attempts. Try again in 15 minutes.':'هەوڵەکان زۆرن. دوای ١٥ خولەک دووبارە هەوڵبدە.','Use a password of 10–128 characters.':'وشەی نهێنی دەبێت لە نێوان ١٠ و ١٢٨ پیت بێت.'};setError(errors[e.message]||'داواکارییەکە بەڕێوە نەچوو. دووبارە هەوڵبدە.');}finally{setBusy(false);}
 }
 const title=action==='verify'||action==='request_verification'?'پشتڕاستکردنەوەی ئیمەیڵ':'گەڕاندنەوەی وشەی نهێنی';
 return <main dir="rtl" className="min-h-screen flex items-center justify-center px-5 py-10 bg-slate-50 text-slate-800"><div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6"><h1 className="text-xl font-bold mb-5">Cadence</h1>
 {loading?<p>چاوەڕێبە...</p>:success?<><h2 className="text-lg font-semibold">{action==='verify'?'ئیمەیڵەکەت پشتڕاست کرایەوە.':'وشەی نهێنیت گۆڕدرا.'}</h2><p className="text-sm mt-3">بە وشەی نهێنیی نوێ بچۆ ژوورەوە.</p><a href="/" className="block mt-5 rounded-xl bg-teal-600 px-4 py-3 text-center text-white">چوونەژوورەوە</a></>:<><h2 className="text-lg font-semibold mb-4">{title}</h2><p className="text-sm mb-4">{requestMode?'ئیمەیڵی هەژمارەکەت بنووسە تا لینکی پارێزراو داوا بکەیت.':action==='verify'?'بۆ پشتڕاستکردنەوەی خاوەندارێتی هەژمار، وشەی نهێنییەکی نوێ دیاری بکە.':'وشەی نهێنییەکی نوێ دیاری بکە. لینکەکە تەنها جارێک کار دەکات.'}</p>
 <form onSubmit={submit} className="space-y-4">{requestMode?<label className="block text-sm">ئیمەیڵ<input type="email" dir="ltr" required maxLength={254} autoComplete="email" value={email} disabled={busy} onChange={e=>setEmail(e.target.value)} className="w-full rounded-xl border border-slate-200 px-4 py-3"/></label>:<><label className="block text-sm">وشەی نهێنیی نوێ<input type="password" dir="ltr" required minLength={10} maxLength={128} autoComplete="new-password" value={password} disabled={busy} onChange={e=>setPassword(e.target.value)} className="w-full rounded-xl border border-slate-200 px-4 py-3"/></label><label className="block text-sm">دووبارەکردنەوەی وشەی نهێنی<input type="password" dir="ltr" required minLength={10} maxLength={128} autoComplete="new-password" value={confirm} disabled={busy} onChange={e=>setConfirm(e.target.value)} className="w-full rounded-xl border border-slate-200 px-4 py-3"/></label><p className="text-xs">لانیکەم ١٠ پیت. دوای پاشەکەوتکردن، دەبێت دووبارە بچیتە ژوورەوە.</p></>}
 {error&&<p role="alert" className="text-sm text-red-600">{error}</p>}{message&&<p role="status" className="text-sm text-teal-600">{message}</p>}
 <button disabled={busy} type="submit" className="w-full rounded-xl bg-teal-600 px-4 py-3 font-semibold text-white">{busy?'چاوەڕێبە...':requestMode?'داواکردنی لینک':'پاشەکەوتکردن'}</button></form><a href="/" className="block mt-4 text-center text-sm underline">گەڕانەوە بۆ چوونەژوورەوە</a>{!requestMode&&<a href={action==='verify'?'/account?mode=verify':'/account?mode=reset'} className="block mt-4 text-center text-sm underline">داواکردنی لینکی نوێ</a>}</>}
 {success&&action==='reset'&&<p className="text-sm mt-4">ئەگەر ئیمەیڵەکەت هێشتا پشتڕاست نەکراوەتەوە، <a href="/account?mode=verify" className="underline">لینکی پشتڕاستکردنەوە داوا بکە.</a></p>}
 </div></main>;
}
